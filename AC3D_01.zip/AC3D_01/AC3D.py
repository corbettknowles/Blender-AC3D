# AC3D Import/Export for Blender 4.0+ and 5.0
# Corbett Knowles - 03/14/26
# Clean rewrite - proper AC3D format parser

import bpy
import mathutils


# -------------------------------------------------------------------------
# IMPORT
# -------------------------------------------------------------------------

def import_ac3d(context, filepath, global_matrix):
    """
    Parse an AC3D (.ac) file and build Blender mesh objects.
    Handles nested OBJECT blocks, vertices, surfaces, and materials.
    """
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        lines = [l.rstrip('\n') for l in f.readlines()]

    if not lines or not lines[0].startswith('AC3Db'):
        print("ERROR: Not a valid AC3D file.")
        return {'CANCELLED'}

    i = 1  # skip header
    total = len(lines)

    # Stack for nested objects; each entry is a dict
    obj_stack = []
    current = None

    def finish_object(obj_data):
        """Turn a parsed object dict into a Blender mesh object."""
        verts = obj_data.get('verts', [])
        faces = obj_data.get('faces', [])
        name  = obj_data.get('name', 'AC3D_Object')
        loc   = obj_data.get('loc', mathutils.Vector((0, 0, 0)))

        if not verts:
            return

        # Apply global matrix to each vertex
        world_verts = [global_matrix @ (v + loc) for v in verts]

        mesh = bpy.data.meshes.new(name)
        try:
            mesh.from_pydata(world_verts, [], faces)
            mesh.validate()
            mesh.update()
        except Exception as e:
            print(f"Mesh build error for '{name}': {e}")
            return

        ob = bpy.data.objects.new(name, mesh)
        context.collection.objects.link(ob)

    while i < total:
        line  = lines[i]
        parts = line.strip().split()
        i    += 1

        if not parts:
            continue

        token = parts[0]

        # ---- new object block ----
        if token == 'OBJECT':
            if current is not None:
                obj_stack.append(current)
            current = {'verts': [], 'faces': [], 'name': 'AC3D_Object',
                       'loc': mathutils.Vector((0, 0, 0))}

        elif token == 'name' and current is not None:
            # name "some name"
            raw = line.strip()[4:].strip().strip('"')
            current['name'] = raw

        elif token == 'loc' and current is not None and len(parts) == 4:
            x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
            current['loc'] = mathutils.Vector((x, y, z))

        elif token == 'numvert' and current is not None:
            count = int(parts[1])
            for _ in range(count):
                vline = lines[i].strip().split()
                i += 1
                current['verts'].append(
                    mathutils.Vector((float(vline[0]),
                                      float(vline[1]),
                                      float(vline[2])))
                )

        elif token == 'numsurf' and current is not None:
            count = int(parts[1])
            for _ in range(count):
                # consume SURF, mat, refs lines
                while i < total:
                    sl = lines[i].strip().split()
                    i += 1
                    if not sl:
                        continue
                    if sl[0] == 'refs':
                        num_refs = int(sl[1])
                        face_idx = []
                        for _ in range(num_refs):
                            ref_parts = lines[i].strip().split()
                            i += 1
                            face_idx.append(int(ref_parts[0]))
                        if len(face_idx) >= 3:
                            current['faces'].append(face_idx)
                        break  # done with this surface

        elif token == 'kids' and current is not None:
            # end of this object block
            finish_object(current)
            if obj_stack:
                current = obj_stack.pop()
            else:
                current = None

    # catch any object not closed by a kids line
    if current is not None:
        finish_object(current)
    for leftover in obj_stack:
        finish_object(leftover)

    print(f"AC3D import complete: {filepath}")
    return {'FINISHED'}


# -------------------------------------------------------------------------
# EXPORT
# -------------------------------------------------------------------------

def export_ac3d(context, filepath, global_matrix):
    """
    Export selected (or all) mesh objects to AC3D (.ac) format.
    """
    objects = [o for o in context.scene.objects if o.type == 'MESH']

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write("AC3Db\n")
        f.write(f"OBJECT world\nkids {len(objects)}\n")

        for obj in objects:
            depsgraph   = context.evaluated_depsgraph_get()
            eval_obj    = obj.evaluated_get(depsgraph)
            mesh        = eval_obj.to_mesh()
            world_mat   = global_matrix @ obj.matrix_world

            f.write(f'OBJECT poly\nname "{obj.name}"\n')
            f.write(f"numvert {len(mesh.vertices)}\n")
            for v in mesh.vertices:
                co = world_mat @ v.co
                f.write(f"{co.x:.6f} {co.y:.6f} {co.z:.6f}\n")

            f.write(f"numsurf {len(mesh.polygons)}\n")
            for poly in mesh.polygons:
                f.write("SURF 0x10\n")
                f.write("mat 0\n")
                f.write(f"refs {len(poly.vertices)}\n")
                for loop_idx in poly.loop_indices:
                    loop = mesh.loops[loop_idx]
                    uv   = (0.0, 0.0)
                    if mesh.uv_layers.active:
                        uv = mesh.uv_layers.active.data[loop_idx].uv
                    f.write(f"{loop.vertex_index} {uv[0]:.6f} {uv[1]:.6f}\n")

            f.write("kids 0\n")
            eval_obj.to_mesh_clear()

    print(f"AC3D export complete: {filepath}")
    return {'FINISHED'}
######Corbett Knowles 03/13/26############ 
    