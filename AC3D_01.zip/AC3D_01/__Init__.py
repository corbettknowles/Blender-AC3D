#Importer/exporter for AC3D plugin

bl_info = {
    "name": "AC3D Import/Export",
    "author": "Your Name",
    "version": (1, 0),
    "blender": (4, 0, 0),
    "location": "File > Import-Export",
    "description": "Import and Export AC3D (.ac) files",
    "category": "Import-Export",
}

import bpy
import mathutils
from bpy_extras.io_utils import ExportHelper, ImportHelper, axis_conversion
from bpy.props import EnumProperty, StringProperty
import os
from .AC3D import import_ac3d, export_ac3d
# ------------------------
# Export Function Stub
# ------------------------

# ------------------------
# Export Operator
# ------------------------
class ExportAC3D(bpy.types.Operator, ExportHelper):
    bl_idname = "export_scene.ac3d"
    bl_label = "Export AC3D"
    filename_ext = ".ac"

    axis_forward: EnumProperty(
        name="Forward",
        items=(('X','X',''), ('Y','Y',''), ('Z','Z',''),
               ('-X','-X',''), ('-Y','-Y',''), ('-Z','-Z','')),
        default='Y'
    )
    axis_up: EnumProperty(
        name="Up",
        items=(('X','X',''), ('Y','Y',''), ('Z','Z',''),
               ('-X','-X',''), ('-Y','-Y',''), ('-Z','-Z','')),
        default='Z'
    )

    def execute(self, context):
        global_matrix = axis_conversion(
            from_forward=self.axis_forward,
            from_up=self.axis_up
        ).to_4x4()
        return export_ac3d(context, self.filepath, global_matrix)

# ------------------------
# Import Operator
# ------------------------
class ImportAC3D(bpy.types.Operator, ImportHelper):
    bl_idname = "import_scene.ac3d"
    bl_label = "Import AC3D"
    filename_ext = ".ac"

    axis_forward: EnumProperty(
        name="Forward",
        items=(('X','X',''), ('Y','Y',''), ('Z','Z',''),
               ('-X','-X',''), ('-Y','-Y',''), ('-Z','-Z','')),
        default='Y'
    )
    axis_up: EnumProperty(
        name="Up",
        items=(('X','X',''), ('Y','Y',''), ('Z','Z',''),
               ('-X','-X',''), ('-Y','-Y',''), ('-Z','-Z','')),
        default='Z'
    )

    def execute(self, context):
        global_matrix = axis_conversion(
            from_forward=self.axis_forward,
            from_up=self.axis_up
        ).to_4x4()
        return import_ac3d(context, self.filepath, global_matrix)

# ------------------------
# Registration
# ------------------------
classes = (ExportAC3D, ImportAC3D)

def menu_func_export(self, context):
    self.layout.operator(ExportAC3D.bl_idname, text="AC3D (.ac)")

def menu_func_import(self, context):
    self.layout.operator(ImportAC3D.bl_idname, text="AC3D (.ac)")

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)

if __name__ == "__main__":
    register()
	
	#######Corbett Knowles 03/13/26#####